from pymongo import MongoClient 
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB"""
    
    def __init__(self, USER, PASS):
        
        USER = 'aacuser'
        PASS = 'SNHU1234'
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 30076
        DB = 'AAC'
        COL = 'animals'
        
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER, PASS, HOST, PORT))
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]
        print ("Connection Successful!")
   
# Complete this create method to implement the C in CRUD
 
    def create(self, data):
        """ Inserts a document unto the Animal collection. """
        
        if data is not None:
            try:
                self.collection.insert_one(data)
                return True
            
            except Exception as e:
                print(f"Error inserting document: {e}")
                return False 
        else:
            raise Exception("Error: Data parameter is empty")
  
  # Create method to implement the R in CRUD 
            
    def read (self, query=None):
        documents = []
        if query: 
            try:
                result = self.collection.find(query)
                for document in result:
                    documents.append(document)
                return documents
            
            except Exception as e:
                print(f"Error reading data: {e}")
                
                return []
                
        else:
            try:
                result = self.collection.find()
                for document in result:
                    documents.append(document)
                return documents
            
            except Exception as e:
                print (f"Error reading data: {e}")
                
                return[]
            
    # Update method to Implemente the U in CRUD
    def update(self, query, update_data):
        """Updates document(s) in the Animal collection based on query"""
        if query and update_data:
            try:
                result = self.collection.update_many(query, {'$set': update_data})
                return result.modified_count
                
            except Exception as e:
                print(f"Error updating document(s): {e}")
                return 0
        else:
            raise Exception("Error: Query or update_data parameter is empty")
                
    # Delete method to implement the D in CRUD
    def delete(self, query):
        """Deletes document(s) from the Animal collection based on query"""
        if query:
            try:
                result = self.collection.delete_many(query)
                return result.deleted_count
                
            except Exception as e:
                print(f"Error deleting document(s): {e}")
                return 0
        else:
            raise Exception("Error: Query parameter is empty")
            
                    
                
                
        
        